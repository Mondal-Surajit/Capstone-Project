
export interface IProduct {
    id: string;
    name: string;
    description: string;
    manufacturer: string;
    price:number;
    qty:number;
  }
  
 