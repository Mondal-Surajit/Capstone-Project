import { Component } from '@angular/core';

@Component({
  selector: 'not-found',
  template : `<h2> Error 404 - Page Not Found`,
  styleUrls: ['./app.component.css']
})
export class PageNotFoundComponent {
  
}
