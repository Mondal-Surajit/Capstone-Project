
export class User {
    id:number;
    mailid: string;
    password: string;
    firstname: string;
    lastname: string;
    location: string;
    mobile:number;
}